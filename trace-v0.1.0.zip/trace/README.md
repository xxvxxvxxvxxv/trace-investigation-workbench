# TRACE

**Open-Source Investigation Workbench** · v0.1.0 · MIT

TRACE is a local-first workspace for organizing open-source investigations. Keep evidence, entities, sources, timelines, hypotheses, and unanswered questions connected in one browser-based analyst environment.

The application is a standalone software project. Its only seeded investigation is **Harbor Signal**, an explicitly fictional training scenario. Real investigations belong in a private local workspace, not in this repository.

## Screenshots

Screenshot slots for a release review:

- Dashboard and investigation overview — pending capture.
- Relationship graph and evidence details — pending capture.
- Case report — pending capture.

No synthetic application screenshots are included. Any future captures must use the fictional demo only; place them in `screenshots/`.

## Core features

- Create, edit, archive, and switch cases with scope, jurisdiction, objectives, references, and priorities.
- Record evidence provenance, reliability, confidence, observed/collected dates, tags, and linked records.
- Track entities, custom attributes, aliases, relationships, sources, and analyst notes.
- Explore entity, evidence, location, source, event, and hypothesis nodes in Cytoscape with five layouts, type filters, zoom, selection, and relationship editing.
- Reconstruct timelines with confidence and source links; export filtered evidence and timeline tables to CSV.
- Place Leaflet markers using a map click or coordinates, categorize them, and connect locations with analyst-defined route lines.
- Track leads, hypotheses with supporting and contradicting evidence, and information gaps with resolution notes.
- Search across all cases and records; maintain a global OSINT tool library with favorites and last-used timestamps.
- Attach files up to 10 MB each, preview common image formats, record SHA-256 hashes, and download originals.
- Export the whole database or an individual case as versioned JSON, including attachment bytes.
- Validate and import non-overlapping backups atomically. Existing records are never silently overwritten.
- Generate printable case reports with browser print-to-PDF support.

## Quick start

Prerequisites: Node.js 22 LTS and npm; a modern browser with IndexedDB and Web Crypto support.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. The demo is created on the first launch only.

```bash
npm run typecheck
npm run test
npm run build
```

The production build is written to `dist/`. Serve it with a static HTTP server; do not open `index.html` directly with `file://`. Hash-based React Router navigation works on static hosts without a route rewrite. Localhost is suitable for development; use HTTPS when hosting so attachment hashing works.

For a repeatable dependency install from this distribution, use `npm ci`.

## First investigation

1. Explore Harbor Signal. All names and evidence are fictional; map coordinates are illustrative.
2. Create a new case using **New case**, **Cases**, or **Quick add**.
3. Add sources, entities, and evidence. Use linked-record checkboxes to associate them.
4. Record timeline events and locations. Use **Graph** to inspect and create relationships.
5. Add competing hypotheses, evidence for and against them, leads, and information gaps.
6. Export a backup in **Settings**. Keep originals outside browser storage.
7. Open **Reports** and print the selected case, or save it as a PDF using the browser.

To archive a case, edit its status to `archived`. Archived cases remain selectable and editable. They are excluded from the active-investigation count.

## Architecture

TRACE is a client-only React application. Dexie wraps IndexedDB; reactive queries update views after local mutations. No server API, cloud database, login, or synchronization service is required.

Domain records use a discriminated `kind` field and a shared typed envelope. A field registry defines forms, linked-record targets, report fields, and table filters. Values are stored as strings, including comma-separated UUID references; numeric coordinates are validated at write and import boundaries. This keeps v0.1 extensible without duplicating form logic across eleven record types. A future schema migration can introduce stronger per-kind value types without changing the external record identity.

Database mutations run through `src/db/database.ts`. Record creation and human-readable ID allocation occur in the same transaction. Backups are validated before a transaction writes them. File bytes are hashed using Web Crypto. The interface renders notes as text and never as raw HTML.

## Technology stack

| Component         | Technology                            |
| ----------------- | ------------------------------------- |
| Interface         | React, TypeScript strict mode         |
| Build             | Vite                                  |
| Navigation        | React Router, hash routing            |
| Local persistence | Dexie.js, IndexedDB                   |
| Reactive reads    | dexie-react-hooks                     |
| Graph             | Cytoscape.js                          |
| Map               | Leaflet; optional OpenStreetMap tiles |
| Icons             | Lucide React                          |
| Styles            | Custom responsive CSS                 |
| Tests             | Vitest, fake-indexeddb                |

## Project structure

```text
src/
  components/   Record editor, details, attachment previews
  pages/        Dashboard, lists, reports, settings, ethics
  features/     Graph and map
  db/           Schema, transactions, integrity tests
  models/       Domain types and field registry
  data/         Fictional demo and reference tool catalog
  utils/        Backup validation, import/export, CSV
  styles/       Theme, responsive layout, print styles
  App.tsx       Workspace navigation and active-case composition
  main.tsx      Bootstrap and error boundary
  hooks/        Reserved for extracted shared hooks
  types/        Reserved for integration-specific declarations
docs/           Data model and release validation notes
screenshots/    Demo-only release screenshots
```

## Data model summary

| Store           | Purpose                                                                                               |
| --------------- | ----------------------------------------------------------------------------------------------------- |
| `records`       | Cases, evidence, entities, timeline events, locations, leads, hypotheses, gaps, sources, tools, notes |
| `relationships` | Explicit directed links with case, source, target, and type                                           |
| `attachments`   | Blob, filename, MIME type, size, SHA-256, record and case IDs                                         |
| `activity`      | Local case activity descriptions and timestamps; not a tamper-proof audit log                         |
| `counters`      | Transactional human-readable IDs per case and record kind                                             |
| `meta`          | Initialization and active-case state                                                                  |

UUIDs identify records internally. Evidence IDs (`E001`), hypothesis IDs (`H001`), gap IDs (`IG001`), lead IDs (`L001`), and other display codes are allocated per case. Tools are global. Case numbers are analyst-editable display references, not database keys.

See [the data model](docs/data-model.md) for backup behavior and limitations.

## Local-first privacy model

The source repository contains application code and fictional sample data only. Actual work remains in IndexedDB in the current browser profile and origin. Opening TRACE at a different address or in another browser creates a separate workspace.

There are no analytics scripts, automatic evidence uploads, remote AI calls, or automatic Git commits. The hosted app shell can be private while case data remains local to each browser.

Optional OpenStreetMap tiles expose your IP and viewed map area to the tile provider. They are disabled by default. External tool and source links open independently and may be subject to provider logging and terms. The seed catalog is a reference directory; pricing, account needs, availability, and coverage should be verified at each provider.

## Security and privacy considerations

- Browser storage is **not an evidence archive**. Clearing site data, private browsing, eviction, profile loss, or device loss can remove your work.
- Export regularly. JSON backups contain cleartext investigation data and attachment bytes; store and share them deliberately.
- TRACE does not encrypt records or provide app-level authentication. Protect the device and browser profile.
- A SHA-256 hash detects changes relative to that recorded hash; it does not prove authenticity or establish legal chain of custody.
- Record deletion removes incoming typed links, manual edges, and attached files. Case deletion removes its records and activity. Export first.
- Backups are limited to 100 MB on import; attachments are limited to 10 MB each. Large investigations may need case-by-case exports or a later streaming format.
- URL fields accept HTTP(S) only. React escapes text; image previews are restricted to common raster formats. CSV exports prefix formula-leading cells.
- Import rejects unsupported versions, malformed references, unsafe URLs, inconsistent attachment bytes/hashes, and overlapping record IDs.
- This v0.1 release is not independently security-audited. See [SECURITY.md](SECURITY.md).

## Ethical use

TRACE supports lawful public-source research and documentation. Users must comply with applicable law, platform terms, privacy requirements, and investigative ethics. Do not use it for unauthorized access, credential theft, stalking, harassment, doxxing, impersonation, or interference with police investigations. Record uncertainties and contradictions; minimize personal data and avoid unsupported allegations.

## Roadmap

- Offline-installable app shell / PWA.
- Encrypted backup format and streaming large-attachment exports.
- Stronger per-kind value types and versioned schema migrations.
- Richer graph legends, saved layouts, and relationship history.
- Multi-case source deduplication and conflict-resolution imports.
- More comprehensive accessibility, cross-browser, and large-case performance review.
- Optional collaboration, cloud sync, authentication, and AI integrations only after the single-user workflow matures.

No visible control depends on these planned features. v0.1 provides browser-based printing rather than a separate PDF renderer.

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md). Use fictional fixtures only. Never attach live case exports to issues or pull requests.

## License

[MIT](LICENSE). Third-party libraries and external map data retain their respective licenses and terms.
