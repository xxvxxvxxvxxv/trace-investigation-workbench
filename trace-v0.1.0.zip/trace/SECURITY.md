# Security policy

## Supported release

TRACE v0.1.x receives fixes on a best-effort basis. This is an early local-first application, not an independently audited evidence-management system.

## Reporting vulnerabilities

Do not publish an issue containing a working exploit against a deployed instance or private investigation data. If the GitHub repository offers private vulnerability reporting, use **Security → Report a vulnerability**. If that feature is not enabled, open a minimal issue requesting a private reporting channel without technical exploit details or sensitive data. No monitored security email is configured in this distribution.

Include affected version, browser, impact, and a minimal reproduction with fictional records. Do not attach real backups. Maintainers should acknowledge receipt, reproduce in an isolated environment, coordinate a fix, and agree on disclosure before publishing details.

## Threat model

The intended boundary is one trusted browser profile on a trusted device. Same-origin scripts, malicious browser extensions, local account compromise, or an attacker who can read the browser profile can access IndexedDB. TRACE does not provide encryption, app passwords, server-side access control, or a tamper-evident audit trail.

External links and optional map tiles leave the application's local boundary. JSON exports include attachment data in cleartext. Treat backups as sensitive documents. Preserve originals separately and maintain backups suitable for your own retention requirements.

## Defensive measures

- React text rendering; no investigator-supplied HTML execution.
- HTTP(S)-only URL validation on forms and imports.
- Raster-only inline attachment previews; other files download as originals.
- File size limits and SHA-256 integrity verification on backup import.
- Case/reference validation and transactional import with collision rejection.
- Formula-leading CSV cell protection.
- No telemetry or automated investigation-data transmission.

These measures reduce specific risks; they do not establish legal admissibility or guarantee safety against malicious local software.
