# TRACE data model and backup contract

## Record envelope

Every record has `id` (UUID), `kind`, `caseId`, `code`, `title`, `createdAt`, `updatedAt`, and a string-valued `values` object. A case's `caseId` equals its own UUID. Tools use an empty case ID and are shared across the workspace. Other records belong to exactly one case.

The field registry in `src/models/schema.ts` is authoritative for v0.1 form fields. Typed link fields store comma-separated target UUIDs. Multiple linked records are supported, except that relationships use explicit source/target endpoints. Calendar inputs labeled UTC are interpreted as UTC; record creation and update metadata use ISO UTC timestamps.

`records` indexes include kind, case ID, compound case/kind, and update date. Relationship endpoints and attachment record IDs have separate indexes. Human codes are generated atomically with record insertion; deletions do not recycle numbers.

## Directed relationships

Explicit edges store source, target, type, and case ID. Both endpoints must be in the same case. Graph-derived links are reconstructed from typed record fields; they cannot be removed independently of the underlying field. Remove an explicit edge by selecting it and using the removal control. Remove a derived edge by editing the owning record's linked fields.

ROUTE edges connect location records and render as straight dashed lines. They do not imply road routing or verified movement.

## Backup version 1

A backup contains `format: "TRACE"`, `version: 1`, `scope`, `exportedAt`, `records`, `relationships`, `activity`, and `attachments`. Attachment blobs become base64 `data` strings while retaining metadata and hash. Database exports include global tools; individual-case exports contain only records owned by that case and strip links outside their scope.

Import is additive into an empty or non-overlapping workspace. It rejects conflicting record, relationship, and attachment IDs. It does not merge divergent versions of the same case. To restore over an existing copy, export current work and remove that copy first, or use a separate browser profile/origin. Whole-workspace clear is available in Settings and requires typing DELETE.

Validation runs before writing. Attachment bytes must match both recorded size and SHA-256. A single IndexedDB transaction applies imported records and counters. Unsupported future versions are rejected rather than guessed. Never hand-edit a backup to bypass reference checks.

## Deletion

Deleting a record removes its files, explicit incident edges, and incoming typed links. Deleting a case removes the case, owned records, attached files, relationships, and case activity. References to that case in other records are removed. Counters retain their maximum values to avoid reusing display codes during the current workspace lifecycle.

## Limitations

Values remain string-based; attributes are freeform key/value notes. No legal chain-of-custody guarantees, immutable history, encryption, synchronization, conflict resolution, or attachment streaming are provided. Live charts and counters describe the selected case, except total/active case counts, which are workspace-wide. Sources are case-owned even when their metadata links other cases; multi-case source deduplication is planned.
