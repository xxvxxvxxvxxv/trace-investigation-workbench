# Release validation

## Automated integrity checks

`npm test` exercises the Dexie database with fake-indexeddb:

- Demo initialization is idempotent and record counts match the specification.
- Concurrent writes allocate unique per-case evidence codes.
- Database backups round-trip and imported counters continue correctly.
- Duplicate imports, missing linked records, and unsafe URLs are rejected.
- Deletion cleans incoming links and explicit relationships.
- Case exports omit global tools; CSV formula-leading text is neutralized.
- Coordinate bounds and event time ordering are validated.

`npm run build` performs strict TypeScript checking and creates a production Vite bundle.

## Manual review scope

Review the rendered demo dashboard and main navigation, record creation and persistence across reload, graph and map controls, backup settings, and the printable report. This is a v0.1 smoke review, not exhaustive accessibility, cross-browser, security, or large-dataset certification.

## Browser review limitation

The production build and automated data tests passed. The supervised preview server started, but the available browser rejected the preview connection (`ERR_BLOCKED_BY_CLIENT`). Rendered screenshots and interactive browser smoke tests could not be completed in this environment. Run the manual checks above before presenting v0.1 as a production-ready release.
