import Dexie, { type Table } from "dexie";
import {
  definitions,
  type RecordItem,
  type Kind,
  type Values,
  type Relationship,
  type Attachment,
  type Activity,
  linkedIds,
} from "../models/schema";
export class TraceDatabase extends Dexie {
  records!: Table<RecordItem, string>;
  relationships!: Table<Relationship, string>;
  attachments!: Table<Attachment, string>;
  activity!: Table<Activity, string>;
  counters!: Table<{ id: string; value: number }, string>;
  meta!: Table<{ id: string; value: string }, string>;
  constructor(name = "trace-workbench") {
    super(name);
    this.version(1).stores({
      records: "id,kind,caseId,[caseId+kind],updatedAt",
      relationships: "id,caseId,from,to",
      attachments: "id,caseId,recordId",
      activity: "id,caseId,timestamp",
      counters: "id",
      meta: "id",
    });
  }
}
export const db = new TraceDatabase();
export async function saveRecord(
  kind: Kind,
  caseId: string,
  title: string,
  values: Values,
  existing?: RecordItem,
) {
  if (!title.trim()) throw new Error("A title is required.");
  if (kind !== "cases" && kind !== "tools" && !caseId)
    throw new Error("Create or select a case first.");
  for (const f of definitions[kind].fields) {
    if (f.required && !values[f.key]?.trim())
      throw new Error(`${f.label} is required.`);
    if (f.type === "url" && values[f.key]) {
      const url = new URL(values[f.key]);
      if (!["https:", "http:"].includes(url.protocol))
        throw new Error("Use an http or https URL.");
    }
  }
  if (
    kind === "locations" &&
    (!Number.isFinite(Number(values.latitude)) ||
      !Number.isFinite(Number(values.longitude)) ||
      Math.abs(Number(values.latitude)) > 90 ||
      Math.abs(Number(values.longitude)) > 180)
  )
    throw new Error(
      "Coordinates must be within ±90 latitude and ±180 longitude.",
    );
  if (
    values.endTimestamp &&
    values.timestamp &&
    values.endTimestamp < values.timestamp
  )
    throw new Error("End time must follow the start time.");
  return db.transaction(
    "rw",
    [db.records, db.counters, db.activity],
    async () => {
      let code = existing?.code;
      if (!code) {
        const id = `${kind}:${kind === "tools" ? "global" : caseId}`;
        const count = (await db.counters.get(id))?.value ?? 0;
        await db.counters.put({ id, value: count + 1 });
        code = `${definitions[kind].prefix}${String(count + 1).padStart(3, "0")}`;
      }
      const now = new Date().toISOString();
      const id = existing?.id ?? crypto.randomUUID();
      const record: RecordItem = {
        id,
        kind,
        caseId: kind === "cases" ? id : kind === "tools" ? "" : caseId,
        code,
        title: title.trim(),
        values,
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
      };
      await db.records.put(record);
      await db.activity.add({
        id: crypto.randomUUID(),
        caseId: record.caseId,
        description: `${existing ? "Updated" : "Created"} ${code} · ${record.title}`,
        timestamp: now,
      });
      return record;
    },
  );
}
export async function deleteRecord(record: RecordItem) {
  await db.transaction(
    "rw",
    [db.records, db.relationships, db.attachments, db.activity],
    async () => {
      const ids =
        record.kind === "cases"
          ? (await db.records.where("caseId").equals(record.id).toArray()).map(
              (r) => r.id,
            )
          : [record.id];
      const set = new Set(ids);
      await db.records.bulkDelete(ids);
      await db.relationships
        .filter(
          (r) => set.has(r.from) || set.has(r.to) || r.caseId === record.id,
        )
        .delete();
      await db.attachments.filter((a) => set.has(a.recordId)).delete();
      for (const other of await db.records.toArray()) {
        let changed = false;
        const values = { ...other.values };
        for (const f of definitions[other.kind].fields.filter(
          (f) => f.type === "links",
        )) {
          const before = linkedIds(values[f.key]);
          const after = before.filter((id) => !set.has(id));
          if (before.length !== after.length) {
            values[f.key] = after.join(",");
            changed = true;
          }
        }
        if (changed) await db.records.update(other.id, { values });
      }
      if (record.kind === "cases")
        await db.activity.where("caseId").equals(record.id).delete();
      else
        await db.activity.add({
          id: crypto.randomUUID(),
          caseId: record.caseId,
          description: `Deleted ${record.code} · ${record.title}`,
          timestamp: new Date().toISOString(),
        });
    },
  );
}
export async function addAttachment(record: RecordItem, file: File) {
  if (file.size > 10 * 1024 * 1024)
    throw new Error(
      "Choose a file of 10 MB or less. Keep originals in your evidence archive.",
    );
  const bytes = await file.arrayBuffer();
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  const sha256 = Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  await db.attachments.add({
    id: crypto.randomUUID(),
    recordId: record.id,
    caseId: record.caseId,
    name: file.name,
    mime: file.type,
    size: file.size,
    sha256,
    createdAt: new Date().toISOString(),
    blob: file,
  });
}
