import { useEffect, useRef, useState } from "react";
import cytoscape from "cytoscape";
import { Maximize, Plus, Minus } from "lucide-react";
import { db } from "../db/database";
import {
  definitions,
  linkedIds,
  relationshipTypes,
  type RecordItem,
  type Relationship,
  type Kind,
} from "../models/schema";
const graphKinds: Kind[] = [
  "entities",
  "evidence",
  "locations",
  "sources",
  "timeline",
  "hypotheses",
];
const colors: Partial<Record<Kind, string>> = {
  entities: "#96adcb",
  evidence: "#cea967",
  locations: "#8aa796",
  sources: "#a69cc8",
  timeline: "#81929f",
  hypotheses: "#c78e88",
};
export function Graph({
  records,
  relationships,
  caseId,
  onSelect,
  onError,
  compact = false,
}: {
  records: RecordItem[];
  relationships: Relationship[];
  caseId: string;
  onSelect: (r: RecordItem) => void;
  onError: (s: string) => void;
  compact?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);
  const [layout, setLayout] = useState("cose");
  const [filter, setFilter] = useState("all");
  const [labels, setLabels] = useState(false);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [type, setType] = useState("ASSOCIATED_WITH");
  const [custom, setCustom] = useState("");
  const [edge, setEdge] = useState<Relationship>();
  useEffect(() => {
    if (!ref.current) return;
    const nodes = records.filter(
      (r) =>
        graphKinds.includes(r.kind) && (filter === "all" || r.kind === filter),
    );
    const ids = new Set(nodes.map((r) => r.id));
    const edges: cytoscape.ElementDefinition[] = relationships
      .filter((r) => ids.has(r.from) && ids.has(r.to))
      .map((r) => ({
        data: {
          id: r.id,
          source: r.from,
          target: r.to,
          label: r.type,
          manual: true,
        },
      }));
    for (const r of nodes)
      for (const f of definitions[r.kind].fields.filter(
        (f) => f.type === "links",
      ))
        for (const id of linkedIds(r.values[f.key]))
          if (id !== r.id && ids.has(id))
            edges.push({
              data: {
                id: `${r.id}:${f.key}:${id}`,
                source: ["supporting", "contradicting", "sources"].includes(
                  f.key,
                )
                  ? id
                  : r.id,
                target: ["supporting", "contradicting", "sources"].includes(
                  f.key,
                )
                  ? r.id
                  : id,
                label:
                  f.key === "supporting"
                    ? "SUPPORTS"
                    : f.key === "contradicting"
                      ? "CONTRADICTS"
                      : f.key === "sources"
                        ? "SOURCE_FOR"
                        : "LINKED_TO",
              },
            });
    const cy = cytoscape({
      container: ref.current,
      elements: [
        ...nodes.map((r) => ({
          data: {
            id: r.id,
            label: r.title,
            color: colors[r.kind],
            kind: r.kind,
          },
        })),
        ...edges,
      ],
      style: [
        {
          selector: "node",
          style: {
            label: "data(label)",
            "background-color": "data(color)",
            color: "#c5ceda",
            "font-size": 11,
            "text-valign": "bottom",
            "text-margin-y": 10,
            width: compact ? 22 : 32,
            height: compact ? 22 : 32,
            "text-wrap": "wrap",
            "text-max-width": "110px",
            "border-width": 5,
            "border-color": "#242c36",
          },
        },
        {
          selector: 'node[kind="evidence"]',
          style: { shape: "round-rectangle" },
        },
        { selector: 'node[kind="hypotheses"]', style: { shape: "diamond" } },
        {
          selector: "edge",
          style: {
            width: 1.2,
            "line-color": "#3e4a5b",
            "target-arrow-color": "#3e4a5b",
            "target-arrow-shape": "triangle",
            "curve-style": "bezier",
            label: labels ? "data(label)" : "",
            "font-size": 9,
            color: "#a4afbf",
            "text-background-color": "#11151b",
            "text-background-opacity": 1,
          },
        },
        {
          selector: ":selected",
          style: { "border-color": "#d6ac68", "line-color": "#d6ac68" },
        },
      ],
      layout: {
        name: layout,
        animate: false,
        padding: 40,
      } as cytoscape.LayoutOptions,
      minZoom: 0.15,
      maxZoom: 3,
    });
    cyRef.current = cy;
    cy.on("tap", "node", (e) => {
      const r = records.find((r) => r.id === e.target.id());
      if (r) onSelect(r);
    });
    cy.on("tap", "edge", (e) =>
      setEdge(relationships.find((r) => r.id === e.target.id())),
    );
    const observer = new ResizeObserver(() => {
      cy.resize();
    });
    observer.observe(ref.current);
    return () => {
      observer.disconnect();
      cy.destroy();
    };
  }, [records, relationships, layout, filter, labels, compact, onSelect]);
  return (
    <div className={compact ? "graph-panel compact" : "graph-panel"}>
      {!compact && (
        <div className="toolbar">
          <select
            aria-label="Graph node types"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All node types</option>
            {graphKinds.map((k) => (
              <option key={k} value={k}>
                {definitions[k].label}
              </option>
            ))}
          </select>
          <select
            aria-label="Graph layout"
            value={layout}
            onChange={(e) => setLayout(e.target.value)}
          >
            <option value="cose">Force directed</option>
            <option value="circle">Circle</option>
            <option value="grid">Grid</option>
            <option value="breadthfirst">Hierarchy</option>
            <option value="concentric">Concentric</option>
          </select>
          <label className="check">
            <input
              type="checkbox"
              checked={labels}
              onChange={(e) => setLabels(e.target.checked)}
            />{" "}
            Edge labels
          </label>
        </div>
      )}
      <div ref={ref} className="graph-canvas" />
      <div className="graph-controls">
        <button
          aria-label="Zoom in"
          onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 1.2)}
        >
          <Plus size={16} />
        </button>
        <button
          aria-label="Zoom out"
          onClick={() => cyRef.current?.zoom(cyRef.current.zoom() / 1.2)}
        >
          <Minus size={16} />
        </button>
        <button
          aria-label="Fit graph"
          onClick={() => cyRef.current?.fit(undefined, 40)}
        >
          <Maximize size={16} />
        </button>
      </div>
      <div className="graph-legend">
        {graphKinds.map((k) => (
          <span key={k}>
            <i style={{ background: colors[k] }} />
            {definitions[k].label}
          </span>
        ))}
      </div>
      {!compact && (
        <form
          className="relationship-form"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!from || !to || from === to) {
              onError("Choose two different records.");
              return;
            }
            try {
              await db.relationships.add({
                id: crypto.randomUUID(),
                caseId,
                from,
                to,
                type: type === "CUSTOM" ? custom.trim() : type,
              });
              setFrom("");
              setTo("");
            } catch (e) {
              onError(String(e));
            }
          }}
        >
          <h3>Create relationship</h3>
          {[from, to].map((value, i) => (
            <select
              required
              key={i}
              aria-label={i ? "Target record" : "Source record"}
              value={value}
              onChange={(e) => (i ? setTo : setFrom)(e.target.value)}
            >
              <option value="">{i ? "To record" : "From record"}</option>
              {records
                .filter((r) => graphKinds.includes(r.kind))
                .map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.code} · {r.title}
                  </option>
                ))}
            </select>
          ))}
          <select
            aria-label="Relationship type"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            {relationshipTypes.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          {type === "CUSTOM" && (
            <input
              aria-label="Custom relationship label"
              required
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Relationship label"
            />
          )}
          <button className="primary">Link records</button>
          {edge && (
            <button
              type="button"
              className="danger"
              onClick={async () => {
                if (confirm(`Remove ${edge.type} relationship?`)) {
                  await db.relationships.delete(edge.id);
                  setEdge(undefined);
                }
              }}
            >
              Remove selected: {edge.type}
            </button>
          )}
        </form>
      )}
    </div>
  );
}
