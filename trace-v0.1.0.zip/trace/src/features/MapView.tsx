import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { db } from "../db/database";
import type { RecordItem, Relationship, Values } from "../models/schema";
export function MapView({
  records,
  relationships,
  caseId,
  onAdd,
  onSelect,
  onError,
}: {
  records: RecordItem[];
  relationships: Relationship[];
  caseId: string;
  onAdd: (v: Values) => void;
  onSelect: (r: RecordItem) => void;
  onError: (s: string) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [tiles, setTiles] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [category, setCategory] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const locations = records.filter((r) => r.kind === "locations");
  useEffect(() => {
    if (!ref.current) return;
    const map = L.map(ref.current).setView([50.802, -1.098], 13);
    if (tiles)
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);
    const points: L.LatLngTuple[] = [];
    for (const r of records.filter(
      (r) =>
        r.kind === "locations" &&
        (category === "all" || r.values.category === category),
    )) {
      const p: L.LatLngTuple = [
        Number(r.values.latitude),
        Number(r.values.longitude),
      ];
      if (!p.every(Number.isFinite)) continue;
      points.push(p);
      const content = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = r.title;
      content.append(title);
      const desc = document.createElement("p");
      desc.textContent = `${r.code} · ${r.values.category ?? "Location"}`;
      content.append(desc);
      const button = document.createElement("button");
      button.textContent = "Open record";
      button.onclick = () => onSelect(r);
      content.append(button);
      L.circleMarker(p, {
        radius: 9,
        color: "#d7b278",
        fillColor: "#a07843",
        fillOpacity: 0.8,
        weight: 2,
      })
        .addTo(map)
        .bindPopup(content);
    }
    for (const rel of relationships.filter((r) => r.type === "ROUTE")) {
      const a = records.find(
          (r) => r.id === rel.from && r.kind === "locations",
        ),
        b = records.find((r) => r.id === rel.to && r.kind === "locations");
      if (a && b)
        L.polyline(
          [
            [Number(a.values.latitude), Number(a.values.longitude)],
            [Number(b.values.latitude), Number(b.values.longitude)],
          ],
          { color: "#d7b278", weight: 2, dashArray: "6 8" },
        ).addTo(map);
    }
    if (points.length)
      map.fitBounds(L.latLngBounds(points), { padding: [50, 50], maxZoom: 14 });
    map.on("click", (e) => {
      if (placing) {
        onAdd({
          latitude: e.latlng.lat.toFixed(6),
          longitude: e.latlng.lng.toFixed(6),
        });
        setPlacing(false);
      }
    });
    const observer = new ResizeObserver(() => map.invalidateSize());
    observer.observe(ref.current);
    return () => {
      observer.disconnect();
      map.remove();
    };
  }, [records, relationships, tiles, placing, category, onAdd, onSelect]);
  return (
    <>
      <div className="toolbar">
        <button
          className={placing ? "primary" : ""}
          onClick={() => setPlacing(!placing)}
        >
          {placing ? "Click map to place · Cancel" : "Place marker"}
        </button>
        <button onClick={() => onAdd({})}>Enter coordinates</button>
        <select
          aria-label="Marker category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          {[
            "all",
            "observation",
            "infrastructure",
            "route point",
            "area of interest",
          ].map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
        <label className="check">
          <input
            type="checkbox"
            checked={tiles}
            onChange={(e) => setTiles(e.target.checked)}
          />{" "}
          Online basemap
        </label>
      </div>
      <p className="muted">
        {tiles
          ? "OpenStreetMap receives tile requests revealing your IP and viewed area. Case records are not sent."
          : "Offline coordinate canvas. Enable the online basemap to load OpenStreetMap tiles."}
      </p>
      <div className={`map-canvas ${placing ? "placing" : ""}`} ref={ref} />
      <form
        className="relationship-form"
        onSubmit={async (e) => {
          e.preventDefault();
          if (from === to) {
            onError("Choose two different locations.");
            return;
          }
          await db.relationships.add({
            id: crypto.randomUUID(),
            caseId,
            from,
            to,
            type: "ROUTE",
          });
          setFrom("");
          setTo("");
        }}
      >
        <h3>Connect locations</h3>
        {[from, to].map((value, i) => (
          <select
            key={i}
            aria-label={i ? "Route destination" : "Route origin"}
            required
            value={value}
            onChange={(e) => (i ? setTo : setFrom)(e.target.value)}
          >
            <option value="">{i ? "Destination" : "Origin"}</option>
            {locations.map((r) => (
              <option key={r.id} value={r.id}>
                {r.title}
              </option>
            ))}
          </select>
        ))}
        <button>Create route line</button>
      </form>
      <p className="muted">
        Lines indicate an analyst-defined connection, not a verified travel
        path. Select a route edge in Graph to remove it.
      </p>
      <div className="location-list">
        {locations.map((r) => (
          <button key={r.id} onClick={() => onSelect(r)}>
            <span className="mono">{r.code}</span> {r.title}
            <small>
              {r.values.latitude}, {r.values.longitude}
            </small>
          </button>
        ))}
      </div>
    </>
  );
}
