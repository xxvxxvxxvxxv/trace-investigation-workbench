import { Printer } from "lucide-react";
import {
  definitions,
  linkedIds,
  type RecordItem,
  type Kind,
} from "../models/schema";
export function Reports({
  activeCase,
  records,
}: {
  activeCase?: RecordItem;
  records: RecordItem[];
}) {
  if (!activeCase)
    return <div className="empty">Select a case to prepare a report.</div>;
  const reportKinds: Kind[] = [
    "timeline",
    "evidence",
    "entities",
    "hypotheses",
    "gaps",
    "sources",
  ];
  return (
    <>
      <div className="toolbar no-print">
        <p className="muted">
          Print this report or select “Save as PDF” in your browser.
        </p>
        <button className="primary" onClick={() => window.print()}>
          <Printer size={16} /> Print / Save PDF
        </button>
      </div>
      <article className="report">
        <div className="report-top">
          <span className="logo">
            TRACE<span className="logo-dot">.</span>
          </span>
          <span className="eyebrow">
            CASE REPORT / {activeCase.values.caseNumber || activeCase.code}
          </span>
        </div>
        <h1>{activeCase.title}</h1>
        <p className="muted">
          Generated {new Date().toLocaleDateString()} ·{" "}
          {activeCase.values.status} · {activeCase.values.jurisdiction}
        </p>
        <h2>Case overview</h2>
        {["summary", "objective", "authority", "officialReference"]
          .filter((k) => activeCase.values[k])
          .map((k) => (
            <p key={k}>
              <strong>
                {definitions.cases.fields.find((f) => f.key === k)?.label}:{" "}
              </strong>
              {activeCase.values[k]}
            </p>
          ))}
        {reportKinds.map((kind) => (
          <section key={kind}>
            <h2>{definitions[kind].label}</h2>
            {records
              .filter((r) => r.kind === kind)
              .sort((a, b) =>
                kind === "timeline"
                  ? (a.values.timestamp ?? "").localeCompare(
                      b.values.timestamp ?? "",
                    )
                  : a.code.localeCompare(b.code),
              )
              .map((r) => (
                <div className="report-record" key={r.id}>
                  <h3>
                    {r.code} · {r.title}
                  </h3>
                  {definitions[kind].fields
                    .filter((f) => r.values[f.key])
                    .map((f) => (
                      <p key={f.key}>
                        <strong>{f.label}: </strong>
                        {f.type === "links"
                          ? linkedIds(r.values[f.key])
                              .map((id) => {
                                const target = records.find((r) => r.id === id);
                                return target
                                  ? `${target.code} — ${target.title}`
                                  : "Unavailable";
                              })
                              .join("; ")
                          : r.values[f.key]}
                      </p>
                    ))}
                </div>
              ))}
            {!records.some((r) => r.kind === kind) && <p>No records.</p>}
          </section>
        ))}
        <footer>
          TRACE v0.1.0 · Analyst-generated report. Confidence and source
          reliability reflect recorded assessments.
        </footer>
      </article>
    </>
  );
}
