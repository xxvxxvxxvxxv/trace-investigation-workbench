import { db } from "../db/database";
import {
  definitions,
  kinds,
  linkedIds,
  type RecordItem,
  type Relationship,
  type Activity,
  type Attachment,
} from "../models/schema";
export interface Backup {
  format: "TRACE";
  version: 1;
  exportedAt: string;
  scope: "database" | "case";
  records: RecordItem[];
  relationships: Relationship[];
  activity: Activity[];
  attachments: (Omit<Attachment, "blob"> & { data: string })[];
}
export function download(
  data: Blob | string,
  name: string,
  mime = "application/json",
) {
  const url = URL.createObjectURL(
    data instanceof Blob ? data : new Blob([data], { type: mime }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function encode(blob: Blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = "";
  for (let i = 0; i < bytes.length; i += 8192)
    binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
  return btoa(binary);
}
export async function createBackup(caseId?: string): Promise<Backup> {
  const records = await db.records
    .filter((r) => !caseId || r.caseId === caseId)
    .toArray();
  const ids = new Set(records.map((r) => r.id));
  return {
    format: "TRACE",
    version: 1,
    exportedAt: new Date().toISOString(),
    scope: caseId ? "case" : "database",
    records: records.map((r) => ({
      ...r,
      values: Object.fromEntries(
        Object.entries(r.values).map(([k, v]) => [
          k,
          definitions[r.kind].fields.some(
            (f) => f.key === k && f.type === "links",
          )
            ? linkedIds(v)
                .filter((id) => ids.has(id))
                .join(",")
            : v,
        ]),
      ),
    })),
    relationships: await db.relationships
      .filter((r) => !caseId || r.caseId === caseId)
      .toArray(),
    activity: await db.activity
      .filter((r) => !caseId || r.caseId === caseId)
      .toArray(),
    attachments: await Promise.all(
      (
        await db.attachments
          .filter((r) => !caseId || r.caseId === caseId)
          .toArray()
      ).map(async ({ blob, ...a }) => ({ ...a, data: await encode(blob) })),
    ),
  };
}
const object = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);
const strings = (o: Record<string, unknown>, keys: string[]) =>
  keys.every((k) => typeof o[k] === "string");
export function validateBackup(input: unknown): Backup {
  if (
    !object(input) ||
    input.format !== "TRACE" ||
    input.version !== 1 ||
    !["database", "case"].includes(String(input.scope))
  )
    throw new Error("Unsupported TRACE backup format or version.");
  for (const key of ["records", "relationships", "activity", "attachments"])
    if (!Array.isArray(input[key]))
      throw new Error(`Backup is missing ${key}.`);
  const records = input.records as unknown[];
  const ids = new Set<string>();
  const cases = new Set<string>();
  for (const r of records) {
    if (
      !object(r) ||
      !strings(r, [
        "id",
        "kind",
        "caseId",
        "code",
        "title",
        "createdAt",
        "updatedAt",
      ]) ||
      !kinds.includes(r.kind as (typeof kinds)[number]) ||
      !object(r.values) ||
      !Object.values(r.values).every((v) => typeof v === "string") ||
      ids.has(String(r.id))
    )
      throw new Error("Invalid or duplicate record in backup.");
    ids.add(r.id as string);
    if (r.kind === "cases") {
      if (r.caseId !== r.id) throw new Error("Invalid case identity.");
      cases.add(r.id as string);
    }
  }
  const typed = records as RecordItem[];
  const byId = new Map(typed.map((r) => [r.id, r]));
  for (const r of typed) {
    if (r.kind !== "tools" && !cases.has(r.caseId))
      throw new Error("Record references a missing case.");
    for (const f of definitions[r.kind].fields) {
      const value = r.values[f.key];
      if (f.type === "links")
        for (const id of linkedIds(value)) {
          const target = byId.get(id);
          if (
            !target ||
            target.kind !== f.target ||
            (target.kind !== "cases" && target.caseId !== r.caseId)
          )
            throw new Error("Invalid linked record.");
        }
      if (f.type === "url" && value) {
        try {
          if (!["http:", "https:"].includes(new URL(value).protocol))
            throw new Error();
        } catch {
          throw new Error("Unsafe URL in backup.");
        }
      }
    }
    if (
      r.kind === "locations" &&
      (!r.values.latitude ||
        !r.values.longitude ||
        !Number.isFinite(Number(r.values.latitude)) ||
        !Number.isFinite(Number(r.values.longitude)) ||
        Math.abs(Number(r.values.latitude)) > 90 ||
        Math.abs(Number(r.values.longitude)) > 180)
    )
      throw new Error("Invalid map coordinates.");
  }
  const unique = (arr: unknown[], fields: string[]) => {
    const seen = new Set<string>();
    for (const item of arr) {
      if (!object(item) || !strings(item, fields) || seen.has(String(item.id)))
        throw new Error("Invalid backup item.");
      seen.add(String(item.id));
    }
  };
  unique(input.relationships as unknown[], [
    "id",
    "caseId",
    "from",
    "to",
    "type",
  ]);
  unique(input.activity as unknown[], [
    "id",
    "caseId",
    "description",
    "timestamp",
  ]);
  unique(input.attachments as unknown[], [
    "id",
    "caseId",
    "recordId",
    "name",
    "mime",
    "sha256",
    "createdAt",
    "data",
  ]);
  for (const r of input.relationships as Relationship[]) {
    if (
      !cases.has(r.caseId) ||
      byId.get(r.from)?.caseId !== r.caseId ||
      byId.get(r.to)?.caseId !== r.caseId
    )
      throw new Error("Relationship references missing or unrelated records.");
  }
  for (const a of input.attachments as Backup["attachments"]) {
    if (
      byId.get(a.recordId)?.caseId !== a.caseId ||
      typeof a.size !== "number" ||
      a.size < 0 ||
      a.size > 10 * 1024 * 1024 ||
      a.data.length > 14 * 1024 * 1024
    )
      throw new Error("Invalid attachment.");
  }
  return input as unknown as Backup;
}
export async function importBackup(input: unknown) {
  const b = validateBackup(input);
  const attachments: Attachment[] = [];
  for (const { data, ...a } of b.attachments) {
    let raw: string;
    try {
      raw = atob(data);
    } catch {
      throw new Error("Invalid attachment encoding.");
    }
    const bytes = Uint8Array.from(raw, (c) => c.charCodeAt(0));
    if (bytes.length !== a.size) throw new Error("Attachment size mismatch.");
    const hash = Array.from(
      new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)),
    )
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    if (hash !== a.sha256) throw new Error("Attachment checksum mismatch.");
    attachments.push({ ...a, blob: new Blob([bytes], { type: a.mime }) });
  }
  await db.transaction("rw", db.tables, async () => {
    for (const r of b.records) {
      const old = await db.records.get(r.id);
      if (old)
        throw new Error(
          "This backup overlaps existing records. Import into an empty workspace or remove the existing case first.",
        );
    }
    for (const a of attachments)
      if (await db.attachments.get(a.id))
        throw new Error("Attachment ID collision.");
    for (const r of b.relationships)
      if (await db.relationships.get(r.id))
        throw new Error("Relationship ID collision.");
    await db.records.bulkAdd(b.records);
    await db.relationships.bulkAdd(b.relationships);
    await db.attachments.bulkAdd(attachments);
    await db.activity.bulkPut(b.activity);
    for (const r of b.records) {
      const key = `${r.kind}:${r.kind === "tools" ? "global" : r.kind === "cases" ? "" : r.caseId}`;
      const n = Number(r.code.replace(/^\D+/, ""));
      const old = (await db.counters.get(key))?.value ?? 0;
      if (Number.isFinite(n) && n > old)
        await db.counters.put({ id: key, value: n });
    }
    await db.meta.put({ id: "initialized", value: "1" });
    const c = b.records.find((r) => r.kind === "cases");
    if (c) await db.meta.put({ id: "activeCase", value: c.id });
  });
}
export function csv(records: RecordItem[], kind: (typeof kinds)[number]) {
  const keys = [
    "code",
    "title",
    ...definitions[kind].fields.map((f) => f.key),
    "createdAt",
    "updatedAt",
  ];
  const cell = (v: string) =>
    '"' + (/^[=+\-@\t\r]/.test(v) ? "'" + v : v).replaceAll('"', '""') + '"';
  return (
    "\uFEFF" +
    [
      keys.map(cell).join(","),
      ...records.map((r) =>
        keys
          .map((k) =>
            cell(
              k === "code"
                ? r.code
                : k === "title"
                  ? r.title
                  : k === "createdAt"
                    ? r.createdAt
                    : k === "updatedAt"
                      ? r.updatedAt
                      : (r.values[k] ?? ""),
            ),
          )
          .join(","),
      ),
    ].join("\r\n")
  );
}
