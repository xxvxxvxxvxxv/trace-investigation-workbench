# TRACE v0.2.0-alpha validation

## Automated coverage

The suite retains the original eight behavioral checks, updated to use the v2 domain types. It adds migration, relationship, time, backup, presentation, and graph-state checks.

| Area                   | Coverage                                                                                                                  |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Initialization         | Exactly the fictional Harbor Signal record counts; idempotent seed                                                        |
| Real database upgrade  | Open a populated IndexedDB v1 database through v2; retain record IDs, files, history, and initialization state            |
| Link migration         | Supporting/contradicting evidence, source provenance, geography, entities and event links; source-link deduplication      |
| Malformed legacy data  | Upgrade abort and rollback to v1 for dangling IDs and malformed link tokens; explicit relation diagnostics                |
| Duplicate relations    | Coalesce legacy duplicates while retaining IDs; reject new identical edges, including concurrent writes                   |
| Case codes             | Workspace case scope independent of active case; concurrent case and evidence creation; retained counter high-water marks |
| Relationship integrity | Indexed incoming/outgoing/type queries; missing and cross-case endpoints; semantic direction; metadata preservation       |
| Time                   | Offset normalization, UTC form input, invalid dates and offsets, reversed ranges, qualifiers, precision and uncertainty   |
| Backups                | V2 round trip; v1 JSON conversion; schema metadata; activity ID collisions; malformed arrays, timestamps and relations    |
| Files                  | Byte round trip; size and SHA-256 validation; tamper rejection                                                            |
| Deletion               | Migrated edge and attachment cleanup; provenance reference cleanup; orphan-counter export handling                        |
| CSV                    | Formula-leading cell protection; filtered case data                                                                       |
| Presentation           | Typed field round trip and preservation of numeric attributes and uncertain time metadata                                 |
| Graph runtime          | Retained Core/node identity, position, selection, pan and zoom during incremental updates                                 |

Tests use Vitest, fake-indexeddb, and a headless Cytoscape Core. They are meaningful domain/runtime checks, not a substitute for browser interaction tests.

## Quality gates

```bash
npm ci
npm run format
npm run format:check
npm run lint
npm run typecheck
npm test
npm run build
```

ESLint uses the recommended JavaScript, TypeScript and React Hooks rules, plus promise handling checks. Lint warnings fail the command. TypeScript remains strict. Prettier supplies formatting. GitHub Actions is configured to install from the lockfile and run formatting checks, typecheck, lint, tests, and build.

The foundation pass completed a clean `npm ci`, formatting and lint checks, strict TypeScript, **32 passing tests across 6 files**, and a successful production build. Lint reported zero errors and warnings. `git diff --check` passed, and source review found no color-system changes. CI configuration being present does not establish that GitHub Actions has run in a destination repository.

## First task of the next release: browser smoke tests

Playwright setup is deliberately deferred so this foundation pass remains focused on migration and domain integrity. The previous preview browser connection was blocked; no new rendered-browser pass is claimed here.

The first release task is a small Playwright test on an isolated fictional browser profile:

1. Create a fictional case.
2. Add evidence and link an entity.
3. Reload the page and confirm the same case, evidence, and relationship persist.
4. Move/zoom Graph, edit a record, and verify its viewport and selected node remain.
5. Pan/zoom Map, edit a marker and toggle category/basemap, and verify viewport retention.
6. Inspect reports, attachment previews, keyboard focus, narrow layout, and UTC datetime controls.

Until then, Leaflet's browser behavior and component interactions are source-reviewed but not browser-verified. Cross-browser compatibility, accessibility, large-case performance, and independent security auditing remain outside this alpha's completed checks. The existing interface and color system are retained.
