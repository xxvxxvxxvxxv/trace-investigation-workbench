# Screenshots

Add genuine captures of the fictional Harbor Signal demo here for release documentation. Never include a real case or personal information. Screenshot capture is pending for the initial source distribution.
