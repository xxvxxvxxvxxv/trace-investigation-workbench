import { recordView } from "./presentation/records";
import type { DraftValues } from "./presentation/records";
import type { RecordView } from "./presentation/records";
import { useCallback, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  FolderOpen,
  FileText,
  Users,
  Clock,
  Network,
  Map,
  Compass,
  Lightbulb,
  HelpCircle,
  Link,
  BookOpen,
  ClipboardList,
  Settings as SettingsIcon,
  ShieldCheck,
  Search,
  Plus,
  ChevronRight,
  HardDrive,
  Menu,
  StickyNote,
  X,
} from "lucide-react";
import { db } from "./db/database";
import { definitions, kinds, type Kind } from "./models/schema";
import { RecordEditor } from "./components/RecordEditor";
import { Details } from "./components/Details";
import { RecordList } from "./pages/RecordList";
import { Dashboard } from "./pages/Dashboard";
import { Graph } from "./features/Graph";
import { MapView } from "./features/MapView";
import { Reports } from "./pages/Reports";
import { Settings } from "./pages/Settings";
import { About } from "./pages/About";
const nav = [
  ["dashboard", "Dashboard", LayoutDashboard],
  ["cases", "Cases", FolderOpen],
  ["evidence", "Evidence", FileText],
  ["entities", "Entities", Users],
  ["timeline", "Timeline", Clock],
  ["graph", "Graph", Network],
  ["map", "Map", Map],
  ["leads", "Leads", Compass],
  ["hypotheses", "Hypotheses", Lightbulb],
  ["gaps", "Information Gaps", HelpCircle],
  ["sources", "Sources", Link],
  ["notes", "Notes", StickyNote],
  ["tools", "OSINT Tools", BookOpen],
  ["reports", "Reports", ClipboardList],
  ["settings", "Settings", SettingsIcon],
  ["about", "About / Ethics", ShieldCheck],
] as const;
export function App() {
  const navigate = useNavigate();
  const section = useLocation().pathname.slice(1) || "dashboard";
  const data = useLiveQuery(async () => ({
    records: await db.records.toArray(),
    relationships: await db.relationships.toArray(),
    activity: await db.activity.orderBy("timestamp").reverse().toArray(),
    active: (await db.meta.get("activeCase"))?.value,
  }));
  const [editor, setEditor] = useState<{
    kind: Kind;
    existing?: RecordView;
    initial?: DraftValues;
  }>();
  const [selectedId, setSelectedId] = useState<string>();
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState<{ message: string; error: boolean }>();
  const [mobile, setMobile] = useState(false);
  const [quick, setQuick] = useState(false);
  const onError = useCallback(
    (message: string) => setToast({ message, error: true }),
    [setToast],
  );
  const onSelect = useCallback((r: RecordView) => setSelectedId(r.id), [setSelectedId]);
  const addLocation = useCallback(
    (initial: DraftValues) => setEditor({ kind: "locations", initial }),
    [setEditor],
  );
  const all = useMemo(
    () =>
      data
        ? data.records.map((record) =>
            recordView(record, data.records, data.relationships),
          )
        : [],
    [data],
  );
  if (!data) return <div className="boot">Opening local workspace…</div>;
  const cases = all.filter((r) => r.kind === "cases");
  const activeCase =
    cases.find((r) => r.id === data.active) ??
    cases.find((r) => r.values.status !== "archived") ??
    cases[0];
  const caseId = activeCase?.id ?? "";
  const records = all.filter((r) => r.caseId === caseId && r.kind !== "cases");
  const relationships = data.relationships.filter((r) => r.caseId === caseId);
  const selected = all.find((r) => r.id === selectedId);
  const currentNav = nav.find((n) => n[0] === section);
  const title = currentNav?.[1] ?? "Not found";
  const kind = kinds.includes(section as Kind) ? (section as Kind) : undefined;
  const results = search.trim()
    ? all
        .filter((r) =>
          `${r.title} ${r.code} ${Object.values(r.values).join(" ")}`
            .toLowerCase()
            .includes(search.toLowerCase()),
        )
        .slice(0, 20)
    : [];
  const add = (k: Kind) => {
    setQuick(false);
    if (k !== "cases" && k !== "tools" && !caseId) {
      onError("Create a case first.");
      setEditor({ kind: "cases" });
    } else setEditor({ kind: k });
  };
  return (
    <div className="app">
      <aside className={`sidebar ${mobile ? "open" : ""}`}>
        <div className="brand">
          <span className="brand-icon">
            <Network size={23} />
          </span>
          <span className="logo">
            TRACE<span className="logo-dot">.</span>
          </span>
          <span className="version">0.2α</span>
        </div>
        <div className="workspace-label">INVESTIGATION WORKSPACE</div>
        <nav>
          {nav.map(([path, label, Icon], i) => (
            <NavLink
              key={path}
              to={`/${path}`}
              className={({ isActive }) =>
                `${isActive || (section === "dashboard" && path === "dashboard") ? "active" : ""} ${i === 12 || i === 14 ? "nav-break" : ""}`
              }
              onClick={() => setMobile(false)}
            >
              <Icon size={17} />
              <span>{label}</span>
              {["evidence", "entities", "leads"].includes(path) && (
                <small>{records.filter((r) => r.kind === path).length}</small>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <HardDrive size={17} />
          <div>
            Local workspace<small>Stored on this device</small>
          </div>
          <ShieldCheck size={15} />
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <button
            className="icon-button mobile-menu"
            aria-label="Toggle navigation"
            onClick={() => setMobile(!mobile)}
          >
            <Menu size={20} />
          </button>
          <div className="case-selector">
            <span className="eyebrow">ACTIVE CASE</span>
            <select
              aria-label="Active case"
              value={caseId}
              onChange={(e) => {
                void db.meta.put({ id: "activeCase", value: e.target.value });
                setSelectedId(undefined);
              }}
            >
              {!cases.length && <option value="">No case selected</option>}
              {cases.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.values.caseNumber || c.code} / {c.title}
                  {c.values.status === "archived" ? " [archived]" : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="global-search">
            <Search size={16} />
            <input
              aria-label="Global search"
              placeholder="Search across your workspace…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Escape") setSearch("");
              }}
            />
            {search && (
              <button
                className="icon-button"
                aria-label="Clear search"
                onClick={() => setSearch("")}
              >
                <X size={14} />
              </button>
            )}
            {search && (
              <div className="search-results">
                <span className="eyebrow">
                  ALL CASES ·{" "}
                  {results.length === 20
                    ? "FIRST 20 RESULTS"
                    : `${results.length} RESULTS`}
                </span>
                {results.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      if (r.kind !== "tools")
                        void db.meta.put({ id: "activeCase", value: r.caseId });
                      onSelect(r);
                      setSearch("");
                    }}
                  >
                    <small>
                      {r.code} · {definitions[r.kind].singular}
                    </small>
                    <strong>{r.title}</strong>
                  </button>
                ))}
                {!results.length && <p>No matching records.</p>}
              </div>
            )}
          </div>
          <div className="quick-add">
            <button
              className="primary"
              aria-expanded={quick}
              onClick={() => setQuick(!quick)}
            >
              <Plus size={16} />
              <span>Quick add</span>
            </button>
            {quick && (
              <div className="quick-menu">
                {kinds.map((k) => (
                  <button key={k} onClick={() => add(k)}>
                    {definitions[k].singular}
                  </button>
                ))}
              </div>
            )}
          </div>
        </header>
        <main>
          <div className="breadcrumb">
            Workspace <ChevronRight size={12} /> {title}
          </div>
          <div className="page-heading">
            <div>
              <span className="eyebrow">
                {section === "dashboard"
                  ? "YOUR INVESTIGATION, IN FOCUS"
                  : activeCase?.values.caseNumber || "TRACE WORKSPACE"}
              </span>
              <h1>{section === "dashboard" ? "Workspace overview" : title}</h1>
              <p>
                {kind
                  ? definitions[kind].subtitle
                  : section === "dashboard"
                    ? "Follow the evidence. Connect the facts. Know what comes next."
                    : section === "graph"
                      ? "Explore relationships and trace the evidence behind each connection."
                      : section === "map"
                        ? "Place evidence and events in their geographic context."
                        : section === "reports"
                          ? "Compile a structured, printable account of your investigation."
                          : section === "settings"
                            ? "Manage local storage, backups, and workspace preferences."
                            : ""}
              </p>
            </div>
            {kind && (
              <button className="primary" onClick={() => add(kind)}>
                <Plus size={16} /> Add {definitions[kind].singular.toLowerCase()}
              </button>
            )}
            {section === "dashboard" && (
              <button onClick={() => add("cases")}>
                <Plus size={16} /> New case
              </button>
            )}
          </div>
          {activeCase?.values.tags
            ?.split(",")
            .map((t) => t.trim())
            .includes("demo") && (
            <div className="demo-notice">
              <span>DEMO WORKSPACE</span> Harbor Signal is fictional. Create a new case
              for your own research.
            </div>
          )}
          {section === "dashboard" ? (
            <Dashboard
              all={all}
              records={records}
              activeCase={activeCase}
              relationships={relationships}
              activity={data.activity.filter((a) => a.caseId === caseId)}
              onSelect={onSelect}
              onNavigate={(s) => navigate(`/${s}`)}
              onError={onError}
            />
          ) : kind ? (
            <RecordList
              key={`${kind}:${caseId}`}
              kind={kind}
              records={kind === "cases" || kind === "tools" ? all : records}
              onSelect={onSelect}
              onError={onError}
            />
          ) : section === "graph" ? (
            <Graph
              records={records}
              relationships={relationships}
              caseId={caseId}
              onSelect={onSelect}
              onError={onError}
            />
          ) : section === "map" ? (
            <MapView
              records={records}
              relationships={relationships}
              caseId={caseId}
              onAdd={addLocation}
              onSelect={onSelect}
              onError={onError}
            />
          ) : section === "reports" ? (
            <Reports activeCase={activeCase} records={records} />
          ) : section === "settings" ? (
            <Settings
              caseId={caseId}
              onError={onError}
              onSuccess={(message) => setToast({ message, error: false })}
            />
          ) : section === "about" ? (
            <About />
          ) : (
            <div className="empty">
              <h2>Page not found</h2>
              <button onClick={() => navigate("/dashboard")}>Return to dashboard</button>
            </div>
          )}
          <div className="page-footer">
            <span>TRACE / Open-Source Investigation Workbench</span>
            <span>v0.2.0-alpha · Local-first</span>
          </div>
        </main>
      </div>
      {selected && !editor && (
        <Details
          key={selected.id}
          record={selected}
          records={all}
          onSelect={onSelect}
          onClose={() => setSelectedId(undefined)}
          onEdit={() => {
            setEditor({ kind: selected.kind, existing: selected });
            setSelectedId(undefined);
          }}
          onError={onError}
        />
      )}
      {editor && (
        <RecordEditor
          kind={editor.kind}
          caseId={editor.existing?.caseId ?? caseId}
          existing={editor.existing}
          initial={editor.initial}
          records={all}
          onClose={() => setEditor(undefined)}
          onSaved={(r) => {
            setEditor(undefined);
            if (r.kind === "cases") void db.meta.put({ id: "activeCase", value: r.id });
            setToast({ message: `${r.code} saved locally.`, error: false });
          }}
        />
      )}
      {toast && (
        <div
          className={`toast ${toast.error ? "error" : ""}`}
          role={toast.error ? "alert" : "status"}
        >
          {toast.message}
          <button
            className="icon-button"
            aria-label="Dismiss notification"
            onClick={() => setToast(undefined)}
          >
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
