import type { RecordView } from "../presentation/records";
import { useEffect, useRef, useState } from "react";
import cytoscape from "cytoscape";
import { Maximize, Plus, Minus } from "lucide-react";
import { saveRelationship, deleteRelationship } from "../db/database";
import {
  graphKinds,
  colors,
  syncGraphElements,
  filterGraph,
  runGraphLayout,
} from "./graph/runtime";
import { definitions, relationshipTypes, type Relationship } from "../models/schema";
export function Graph({
  records,
  relationships,
  caseId,
  onSelect,
  onError,
  compact = false,
}: {
  records: RecordView[];
  relationships: Relationship[];
  caseId: string;
  onSelect: (r: RecordView) => void;
  onError: (s: string) => void;
  compact?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);
  const [layout, setLayout] = useState("cose");
  const [filter, setFilter] = useState("all");
  const [labels, setLabels] = useState(false);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [type, setType] = useState("ASSOCIATED_WITH");
  const [custom, setCustom] = useState("");
  const [edge, setEdge] = useState<Relationship>();
  const latest = useRef({ records, relationships, onSelect });
  useEffect(() => {
    latest.current = { records, relationships, onSelect };
  }, [records, relationships, onSelect]);
  const layoutState = useRef<{ caseId: string; layout: string; initialized: boolean }>({
    caseId: "",
    layout: "",
    initialized: false,
  });
  useEffect(() => {
    if (!ref.current) return;
    const cy = cytoscape({
      container: ref.current,
      elements: [],
      style: [
        {
          selector: "node",
          style: {
            label: "data(label)",
            "background-color": "data(color)",
            color: "#c5ceda",
            "font-size": 11,
            "text-valign": "bottom",
            "text-margin-y": 10,
            width: 32,
            height: 32,
            "text-wrap": "wrap",
            "text-max-width": "110px",
            "border-width": 5,
            "border-color": "#242c36",
          },
        },
        {
          selector: 'node[kind="evidence"]',
          style: { shape: "round-rectangle" },
        },
        { selector: 'node[kind="hypotheses"]', style: { shape: "diamond" } },
        {
          selector: "edge",
          style: {
            width: 1.2,
            "line-color": "#3e4a5b",
            "target-arrow-color": "#3e4a5b",
            "target-arrow-shape": "triangle",
            "curve-style": "bezier",
            label: "",
            "font-size": 9,
            color: "#a4afbf",
            "text-background-color": "#11151b",
            "text-background-opacity": 1,
          },
        },
        {
          selector: ":selected",
          style: { "border-color": "#d6ac68", "line-color": "#d6ac68" },
        },
      ],
      layout: { name: "preset" },
      minZoom: 0.15,
      maxZoom: 3,
    });
    cyRef.current = cy;
    cy.on("tap", "node", (e) => {
      const r = latest.current.records.find((r) => r.id === e.target.id());
      if (r) latest.current.onSelect(r);
    });
    cy.on("tap", "edge", (e) =>
      setEdge(latest.current.relationships.find((r) => r.id === e.target.id())),
    );
    const observer = new ResizeObserver(() => {
      cy.resize();
    });
    observer.observe(ref.current);
    return () => {
      observer.disconnect();
      cy.destroy();
      cyRef.current = null;
      layoutState.current = { caseId: "", layout: "", initialized: false };
    };
  }, []);
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    syncGraphElements(
      cy,
      records.map((r) => r.record),
      relationships,
    );
    filterGraph(cy, filter);
    const state = layoutState.current;
    if (state.caseId !== caseId) {
      state.caseId = caseId;
      state.initialized = false;
    }
    if (cy.nodes().length && (!state.initialized || state.layout !== layout)) {
      runGraphLayout(cy, layout, !state.initialized);
      state.initialized = true;
      state.layout = layout;
    }
  }, [records, relationships, filter, layout, caseId]);
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.style()
      .selector("node")
      .style({ width: compact ? 22 : 32, height: compact ? 22 : 32 })
      .selector("edge")
      .style({ label: labels ? "data(label)" : "" })
      .update();
  }, [labels, compact]);
  return (
    <div className={compact ? "graph-panel compact" : "graph-panel"}>
      {!compact && (
        <div className="toolbar">
          <select
            aria-label="Graph node types"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All node types</option>
            {graphKinds.map((k) => (
              <option key={k} value={k}>
                {definitions[k].label}
              </option>
            ))}
          </select>
          <select
            aria-label="Graph layout"
            value={layout}
            onChange={(e) => setLayout(e.target.value)}
          >
            <option value="cose">Force directed</option>
            <option value="circle">Circle</option>
            <option value="grid">Grid</option>
            <option value="breadthfirst">Hierarchy</option>
            <option value="concentric">Concentric</option>
          </select>
          <label className="check">
            <input
              type="checkbox"
              checked={labels}
              onChange={(e) => setLabels(e.target.checked)}
            />{" "}
            Edge labels
          </label>
        </div>
      )}
      <div ref={ref} className="graph-canvas" />
      <div className="graph-controls">
        <button
          aria-label="Zoom in"
          onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 1.2)}
        >
          <Plus size={16} />
        </button>
        <button
          aria-label="Zoom out"
          onClick={() => cyRef.current?.zoom(cyRef.current.zoom() / 1.2)}
        >
          <Minus size={16} />
        </button>
        <button aria-label="Fit graph" onClick={() => cyRef.current?.fit(undefined, 40)}>
          <Maximize size={16} />
        </button>
      </div>
      <div className="graph-legend">
        {graphKinds.map((k) => (
          <span key={k}>
            <i style={{ background: colors[k] }} />
            {definitions[k].label}
          </span>
        ))}
      </div>
      {!compact && (
        <form
          className="relationship-form"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!from || !to || from === to) {
              onError("Choose two different records.");
              return;
            }
            try {
              await saveRelationship({
                caseId,
                from,
                to,
                type: type === "CUSTOM" ? custom.trim() : type,
              });
              setFrom("");
              setTo("");
            } catch (e) {
              onError(String(e));
            }
          }}
        >
          <h3>Create relationship</h3>
          {[from, to].map((value, i) => (
            <select
              required
              key={i}
              aria-label={i ? "Target record" : "Source record"}
              value={value}
              onChange={(e) => (i ? setTo : setFrom)(e.target.value)}
            >
              <option value="">{i ? "To record" : "From record"}</option>
              {records
                .filter((r) => graphKinds.includes(r.kind))
                .map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.code} · {r.title}
                  </option>
                ))}
            </select>
          ))}
          <select
            aria-label="Relationship type"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            {relationshipTypes.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          {type === "CUSTOM" && (
            <input
              aria-label="Custom relationship label"
              required
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Relationship label"
            />
          )}
          <button className="primary">Link records</button>
          {edge && relationships.some((r) => r.id === edge.id) && (
            <button
              type="button"
              className="danger"
              onClick={async () => {
                if (confirm(`Remove ${edge.type} relationship?`)) {
                  try {
                    await deleteRelationship(edge.id);
                    setEdge(undefined);
                  } catch (error) {
                    onError(String(error));
                  }
                }
              }}
            >
              Remove selected: {edge.type}
            </button>
          )}
        </form>
      )}
    </div>
  );
}
