import type { DraftValues } from "../presentation/records";
import type { RecordView } from "../presentation/records";
import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { saveRelationship } from "../db/database";
import { updateMarkers, updateRoutes } from "./map/layers";
import type { Relationship } from "../models/schema";
export function MapView({
  records,
  relationships,
  caseId,
  onAdd,
  onSelect,
  onError,
}: {
  records: RecordView[];
  relationships: Relationship[];
  caseId: string;
  onAdd: (v: DraftValues) => void;
  onSelect: (r: RecordView) => void;
  onError: (s: string) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [tiles, setTiles] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [category, setCategory] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const locations = records.filter((r) => r.kind === "locations");
  const mapRef = useRef<L.Map | null>(null);
  const layersRef = useRef<{
    markers: L.LayerGroup;
    routes: L.LayerGroup;
    basemap: L.LayerGroup;
    tiles?: L.TileLayer;
  } | null>(null);
  const markersRef = useRef(new Map<string, L.CircleMarker>());
  const routesRef = useRef(new Map<string, L.Polyline>());
  const viewport = useRef({ caseId: "", fitted: false });
  const latest = useRef({ placing, onAdd });
  useEffect(() => {
    latest.current = { placing, onAdd };
  }, [placing, onAdd]);
  useEffect(() => {
    if (!ref.current) return;
    const map = L.map(ref.current).setView([50.802, -1.098], 13);
    mapRef.current = map;
    layersRef.current = {
      markers: L.layerGroup().addTo(map),
      routes: L.layerGroup().addTo(map),
      basemap: L.layerGroup().addTo(map),
    };
    map.on("click", (event: L.LeafletMouseEvent) => {
      if (latest.current.placing) {
        latest.current.onAdd({
          latitude: event.latlng.lat.toFixed(6),
          longitude: event.latlng.lng.toFixed(6),
        });
        setPlacing(false);
      }
    });
    const observer = new ResizeObserver(() => map.invalidateSize({ pan: false }));
    observer.observe(ref.current);
    const markers = markersRef.current;
    const routes = routesRef.current;
    return () => {
      observer.disconnect();
      map.remove();
      mapRef.current = null;
      layersRef.current = null;
      markers.clear();
      routes.clear();
      viewport.current = { caseId: "", fitted: false };
    };
  }, []);
  useEffect(() => {
    const map = mapRef.current,
      layers = layersRef.current;
    if (!map || !layers) return;
    const points = updateMarkers(
      layers.markers,
      markersRef.current,
      records,
      category,
      onSelect,
    );
    updateRoutes(layers.routes, routesRef.current, records, relationships, category);
    if (viewport.current.caseId !== caseId) viewport.current = { caseId, fitted: false };
    if (!viewport.current.fitted && points.length) {
      map.fitBounds(L.latLngBounds(points), { padding: [50, 50], maxZoom: 14 });
      viewport.current.fitted = true;
    }
  }, [records, relationships, category, caseId, onSelect]);
  useEffect(() => {
    const layers = layersRef.current;
    if (!layers) return;
    if (tiles) {
      layers.tiles ??= L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      });
      layers.basemap.addLayer(layers.tiles);
    } else layers.basemap.clearLayers();
  }, [tiles]);
  return (
    <>
      <div className="toolbar">
        <button className={placing ? "primary" : ""} onClick={() => setPlacing(!placing)}>
          {placing ? "Click map to place · Cancel" : "Place marker"}
        </button>
        <button onClick={() => onAdd({})}>Enter coordinates</button>
        <select
          aria-label="Marker category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          {[
            "all",
            "observation",
            "infrastructure",
            "route point",
            "area of interest",
          ].map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
        <label className="check">
          <input
            type="checkbox"
            checked={tiles}
            onChange={(e) => setTiles(e.target.checked)}
          />{" "}
          Online basemap
        </label>
      </div>
      <p className="muted">
        {tiles
          ? "OpenStreetMap receives tile requests revealing your IP and viewed area. Case records are not sent."
          : "Offline coordinate canvas. Enable the online basemap to load OpenStreetMap tiles."}
      </p>
      <div className={`map-canvas ${placing ? "placing" : ""}`} ref={ref} />
      <form
        className="relationship-form"
        onSubmit={async (e) => {
          e.preventDefault();
          if (from === to) {
            onError("Choose two different locations.");
            return;
          }
          try {
            await saveRelationship({
              caseId,
              from,
              to,
              type: "ROUTE",
            });
            setFrom("");
            setTo("");
          } catch (error) {
            onError(String(error));
          }
        }}
      >
        <h3>Connect locations</h3>
        {[from, to].map((value, i) => (
          <select
            key={i}
            aria-label={i ? "Route destination" : "Route origin"}
            required
            value={value}
            onChange={(e) => (i ? setTo : setFrom)(e.target.value)}
          >
            <option value="">{i ? "Destination" : "Origin"}</option>
            {locations.map((r) => (
              <option key={r.id} value={r.id}>
                {r.title}
              </option>
            ))}
          </select>
        ))}
        <button>Create route line</button>
      </form>
      <p className="muted">
        Lines indicate an analyst-defined connection, not a verified travel path. Select a
        route edge in Graph to remove it.
      </p>
      <div className="location-list">
        {locations.map((r) => (
          <button key={r.id} onClick={() => onSelect(r)}>
            <span className="mono">{r.code}</span> {r.title}
            <small>
              {r.values.latitude}, {r.values.longitude}
            </small>
          </button>
        ))}
      </div>
    </>
  );
}
