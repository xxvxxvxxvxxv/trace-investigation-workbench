import { describe, it, expect } from "vitest";
import cytoscape from "cytoscape";
import { syncGraphElements } from "./runtime";
import type { RecordItem, Relationship } from "../../models/schema";
import { nowUTC } from "../../models/time";
describe("incremental graph reconciliation", () => {
  it("retains core, node identity, positions, pan, zoom and selection during record changes", () => {
    const cy = cytoscape({ headless: true });
    try {
      const time = nowUTC();
      const a: RecordItem = {
        id: crypto.randomUUID(),
        kind: "entities",
        caseId: crypto.randomUUID(),
        code: "ENT001",
        title: "A",
        createdAt: time,
        updatedAt: time,
        values: {},
      };
      const b = { ...a, id: crypto.randomUUID(), code: "ENT002", title: "B" };
      const edge: Relationship = {
        id: crypto.randomUUID(),
        caseId: a.caseId,
        from: a.id,
        to: b.id,
        type: "USES",
        createdAt: time,
        updatedAt: time,
      };
      syncGraphElements(cy, [a, b], [edge]);
      const node = cy.getElementById(a.id);
      node.position({ x: 123, y: 456 });
      node.select();
      cy.zoom(1.7);
      cy.pan({ x: 22, y: 33 });
      syncGraphElements(cy, [{ ...a, title: "Renamed" }, b], [edge]);
      expect(cy.getElementById(a.id)[0]).toBe(node[0]);
      expect(node.position()).toEqual({ x: 123, y: 456 });
      expect(node.selected()).toBe(true);
      expect(cy.zoom()).toBe(1.7);
      expect(cy.pan()).toEqual({ x: 22, y: 33 });
      expect(node.data("label")).toBe("Renamed");
      syncGraphElements(cy, [a], []);
      expect(cy.nodes()).toHaveLength(1);
      expect(cy.edges()).toHaveLength(0);
    } finally {
      cy.destroy();
    }
  });
});
