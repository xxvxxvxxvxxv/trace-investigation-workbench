Shared domain hooks may be extracted here as workflows grow. Current reactive reads use Dexie hooks at their point of use.
