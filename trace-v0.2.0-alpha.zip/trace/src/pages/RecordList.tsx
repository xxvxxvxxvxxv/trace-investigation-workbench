import type { RecordView } from "../presentation/records";
import { useState } from "react";
import { Search, Download, ArrowUpRight, Star } from "lucide-react";
import { definitions, type Kind } from "../models/schema";
import { csv, download } from "../utils/backup";
import { saveDraft } from "../presentation/saveDraft";
export function Badge({ value }: { value?: string }) {
  return value ? (
    <span className={`badge ${value.toLowerCase().split(" ")[0]}`}>{value}</span>
  ) : (
    <span className="muted">—</span>
  );
}
export function RecordList({
  kind,
  records,
  onSelect,
  onError,
}: {
  kind: Kind;
  records: RecordView[];
  onSelect: (r: RecordView) => void;
  onError: (s: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState(kind === "timeline" ? "chronological" : "recent");
  const field =
    definitions[kind].fields.find((f) => f.key === "status") ??
    definitions[kind].fields.find((f) => f.key === "type") ??
    definitions[kind].fields.find((f) => f.key === "category") ??
    definitions[kind].fields.find((f) => f.key === "confidence");
  const data = records
    .filter(
      (r) =>
        r.kind === kind &&
        (!query ||
          `${r.title} ${r.code} ${Object.values(r.values).join(" ")}`
            .toLowerCase()
            .includes(query.toLowerCase())) &&
        (filter === "all" || r.values[field?.key ?? ""] === filter),
    )
    .sort((a, b) =>
      sort === "title"
        ? a.title.localeCompare(b.title)
        : sort === "chronological"
          ? (a.values.timestamp ?? "").localeCompare(b.values.timestamp ?? "")
          : b.updatedAt.localeCompare(a.updatedAt),
    );
  return (
    <>
      <div className="toolbar">
        <div className="search-field">
          <Search size={16} />
          <input
            aria-label={`Search ${definitions[kind].label}`}
            placeholder={`Search ${definitions[kind].label.toLowerCase()}…`}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {field && (
          <select
            aria-label={`Filter by ${field.label}`}
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All {field.label.toLowerCase()}</option>
            {field.options?.map((v) => (
              <option key={v}>{v}</option>
            ))}
          </select>
        )}
        <select
          aria-label="Sort records"
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option value="recent">Recently updated</option>
          <option value="title">Title A–Z</option>
          {kind === "timeline" && <option value="chronological">Chronological</option>}
        </select>
        <span className="muted count">{data.length} records</span>
        {["evidence", "timeline"].includes(kind) && (
          <button
            onClick={() =>
              download(
                csv(
                  data.map((r) => r.record),
                  kind,
                  data,
                ),
                `TRACE-${kind}.csv`,
                "text/csv;charset=utf-8",
              )
            }
          >
            <Download size={14} /> CSV
          </button>
        )}
      </div>
      {!data.length ? (
        <div className="empty">
          <Search size={28} />
          <h3>
            {records.some((r) => r.kind === kind)
              ? "No matching records"
              : "No records yet"}
          </h3>
          <p>
            {records.some((r) => r.kind === kind)
              ? "Adjust the search or filter."
              : "Add the first record to start building this part of the investigation."}
          </p>
        </div>
      ) : kind === "tools" ? (
        <div className="tool-grid">
          {data.map((r) => (
            <article className="panel tool-card" key={r.id}>
              <div className="section-heading">
                <span className="eyebrow">{r.values.category}</span>
                <button
                  className="icon-button"
                  aria-label={`${r.values.favorite === "yes" ? "Unfavorite" : "Favorite"} ${r.title}`}
                  onClick={async () => {
                    try {
                      await saveDraft(
                        "tools",
                        "",
                        r.title,
                        {
                          ...r.values,
                          favorite: r.values.favorite === "yes" ? "no" : "yes",
                        },
                        r,
                      );
                    } catch (e) {
                      onError(String(e));
                    }
                  }}
                >
                  <Star
                    size={16}
                    fill={r.values.favorite === "yes" ? "currentColor" : "none"}
                  />
                </button>
              </div>
              <button className="text-button" onClick={() => onSelect(r)}>
                <h3>{r.title}</h3>
              </button>
              <p>{r.values.description}</p>
              <div className="section-heading">
                <span className="muted">
                  {r.values.pricing} · account {r.values.account}
                </span>
                <a
                  className="button"
                  href={r.values.url}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => {
                    void saveDraft(
                      "tools",
                      "",
                      r.title,
                      {
                        ...r.values,
                        lastUsed: new Date().toISOString().slice(0, 16),
                      },
                      r,
                    ).catch((e) => onError(String(e)));
                  }}
                >
                  Open <ArrowUpRight size={14} />
                </a>
              </div>
            </article>
          ))}
        </div>
      ) : kind === "timeline" ? (
        <div className="timeline-list">
          {data.map((r) => (
            <button className="timeline-event" key={r.id} onClick={() => onSelect(r)}>
              <time>{r.values.timestamp?.replace("T", " · ")} UTC</time>
              <div>
                <span className="eyebrow">{r.code}</span>
                <h3>{r.title}</h3>
                <p>{r.values.description}</p>
                <Badge value={r.values.confidence} />
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>
                  {kind === "hypotheses"
                    ? "Statement"
                    : kind === "gaps"
                      ? "Question"
                      : "Title"}
                </th>
                <th>{field?.label ?? "Type"}</th>
                <th>
                  {kind === "cases" || kind === "leads" || kind === "gaps"
                    ? "Priority"
                    : "Confidence"}
                </th>
                <th>Updated</th>
                <th>
                  <span className="sr-only">Details</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id}>
                  <td className="mono">
                    {r.kind === "cases" ? r.values.caseNumber || r.code : r.code}
                  </td>
                  <td>
                    <button className="record-link" onClick={() => onSelect(r)}>
                      {r.title}
                    </button>
                    <small className="row-description">
                      {r.values.description ||
                        r.values.summary ||
                        r.values.nextAction ||
                        r.values.publisher}
                    </small>
                  </td>
                  <td>
                    <Badge value={r.values[field?.key ?? "type"]} />
                  </td>
                  <td>
                    <Badge value={r.values.priority || r.values.confidence} />
                  </td>
                  <td className="muted nowrap">
                    {new Date(r.updatedAt).toLocaleDateString("en-GB", {
                      day: "2-digit",
                      month: "short",
                    })}
                  </td>
                  <td>
                    <button
                      className="icon-button"
                      aria-label={`Open ${r.title}`}
                      onClick={() => onSelect(r)}
                    >
                      <ArrowUpRight size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
